var React = require('react');
var Routes = require('./routes');
var Api = require('./utils/api');

React.render(Routes, document.querySelector('.container'));
