module.exports = {
  waitForConditionTimeout: 30000,
};
