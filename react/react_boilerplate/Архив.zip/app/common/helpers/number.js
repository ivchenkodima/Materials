
export const isNA = a => typeof a === 'undefined' || a == null;
