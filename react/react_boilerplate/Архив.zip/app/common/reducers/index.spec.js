
import { expect } from 'chai';
import Reducer from './index';

describe('Reducer', () => {
  it('should be exist', () => {
    expect(Reducer).to.not.be.null;
  });
});
