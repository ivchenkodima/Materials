
export const changeLanguage = lang => (dispatch, getState, { i18n }) =>
  i18n.changeLanguage(lang);
