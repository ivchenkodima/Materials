TestHelpers.commonWidgetTests( "button", {
	defaults: {
		disabled: null,
		icons: {
			primary: null,
			secondary: null
		},
		label: null,
		text: true,

		// callbacks
		create: null
	}
});
