﻿var name = "MODULE 1"; // глобальная переменная

function startModule1() {
    document.write(name + "<br />");
}