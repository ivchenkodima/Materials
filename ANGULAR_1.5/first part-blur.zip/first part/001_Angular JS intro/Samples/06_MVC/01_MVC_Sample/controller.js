﻿ function petCtrl ($scope) {
    $scope.pets = pets;
};