﻿var pets = [
    { name: "Lucky", animal: "Dog" },
    { name: "Lucy", animal: "Cat" }
];