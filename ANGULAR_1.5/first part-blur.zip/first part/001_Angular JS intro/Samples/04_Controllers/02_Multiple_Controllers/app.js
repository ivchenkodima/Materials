﻿function ukraineCtrl ($scope) {
    $scope.country = {
        name: 'Ukraine',
        area: '603 628',
        population: '42 825 883',
        capital: {
            name: 'Kiev'
        }
    };
}

function canadaCtrl($scope) {
    $scope.country = {
        name: 'Canada',
        area: '9 984 670',
        population: '34 568 211',
        capital: {
            name: 'Ottava'
        }
    };
}