﻿function countriesCtrl ($scope) {
    $scope.countries = [{
        name: 'Ukraine',
        area: '603 628',
        population: '42 825 883',
        capital: {
            name: 'Kiev'
        }
    },
    {
        name: 'Canada',
        area: '9 984 670',
        population: '34 568 211',
        capital: {
            name: 'Ottava'
        }
    }];
}